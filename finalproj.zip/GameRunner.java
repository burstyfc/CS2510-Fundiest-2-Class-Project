/*
assignment 8
pair 2
Chao Fang
bursty
Amanda Fode
afode11
 */
/*
class GameRunner implements MarioConstants { 
    Mario mario = new Mario(30, 308);

    MarioWorld mwd = new MarioWorld(this.mario, 4, 0);
    

    public void run(){
        // run the game
        this.mwd.bigBang(width, height, 0.05);
      }
      
      public static void main(String[] argv){
          GameRunner g = new GameRunner();
          g.run();
          
          
          

      }
}
*/